#!/usr/bin/env python3
"""Baixa o código-fonte do snes9x (versão fixa) para app/src/main/cpp/snes9x.

Precisa de `git` e internet. Roda sozinho pelo criar_projeto.py; só execute à mão
se a pasta snes9x estiver faltando. Não faz nada se o código já estiver lá.
"""
import os
import shutil
import stat
import subprocess
import sys

REPO = "https://github.com/snes9xgit/snes9x.git"
SHA = "1bcc369e89f08243e0a462882fb1f3e42e51de3a"   # versão testada


def _rm_readonly(func, path, _exc):
    os.chmod(path, stat.S_IWRITE)
    func(path)


def main(project_dir):
    dest = os.path.join(project_dir, "app", "src", "main", "cpp", "snes9x")
    if os.path.exists(os.path.join(dest, "libretro", "libretro.cpp")):
        print("snes9x já presente em", dest)
        return 0
    if shutil.which("git") is None:
        print("ERRO: instale o git (ou baixe https://github.com/snes9xgit/snes9x e copie para", dest + ")")
        return 1
    os.makedirs(dest, exist_ok=True)

    def run(*args):
        subprocess.run(args, cwd=dest, check=True)

    print("Baixando snes9x", SHA[:8], "...")
    run("git", "init", "-q")
    run("git", "remote", "add", "origin", REPO)
    run("git", "fetch", "-q", "--depth", "1", "origin", SHA)
    run("git", "checkout", "-q", "FETCH_HEAD")
    shutil.rmtree(os.path.join(dest, ".git"), onerror=_rm_readonly)   # evita repositório aninhado
    print("snes9x pronto.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(os.path.abspath(__file__))))
