# Top Gear Android (wrapper nativo + snes9x)

App Android (Kotlin + C++17/JNI) com o core **snes9x** (via API libretro) embutido.
Vídeo na `Surface`, áudio com Oboe, pad virtual multitoque, suporte a controle físico,
saves (SRAM) automáticos e memória da última ROM.

## O que o app faz
1. Na primeira vez, pede o arquivo da ROM (`.sfc`/`.smc`); nas próximas abre direto.
2. O botão **ROM** no topo troca de jogo.
3. O save do jogo é gravado a cada ~30 s e ao sair do app.

A ROM **não** acompanha o app: use um backup do seu próprio cartucho.

## Estrutura
- `app/src/main/cpp/frontend.*`  frontend libretro portátil (vídeo, áudio, entrada, SRAM)
- `app/src/main/cpp/native-lib.cpp`  ponte JNI + `ANativeWindow` + Oboe
- `app/src/main/cpp/host_test.cpp`  teste de ponta a ponta no PC (mini-ROM de teste)
- `app/src/main/cpp/snes9x/`  código do snes9x, baixado na versão fixa do `criar_projeto.py`
- `app/src/main/java/.../MainActivity.kt`  UI, toque e controle

Mapeamento de entrada: o pad vira a palavra `($4219<<8)|$4218` (bits do SNES); o snes9x
a entrega ao jogo pela leitura automática do joypad, como no hardware.

## Compilar o APK
**Android Studio:** File > Open na pasta do projeto, aguarde o sync (baixa NDK/CMake) e Run.
O APK sai em `app/build/outputs/apk/debug/`.

**GitHub Actions:** envie o projeto (ou só o `build-apk.yml`) e baixe o APK em Actions > Artifacts.

**Teste no PC (sem Android):**

    cmake -S app/src/main/cpp -B build -G Ninja -DTOPGEAR_HOST_TEST=ON -DCMAKE_BUILD_TYPE=Release
    cmake --build build && ./build/host_test

## Licenças
O snes9x usa licença própria que **não permite uso comercial**. Este projeto serve para
uso pessoal. Oboe: Apache 2.0.
