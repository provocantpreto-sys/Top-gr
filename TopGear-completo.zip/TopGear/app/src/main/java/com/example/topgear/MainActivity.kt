package com.example.topgear

import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

/**
 * Bits do pad no formato do SNES: palavra de 16 bits = ($4219 shl 8) or $4218.
 * Devem ser idênticos às constantes BTN_* em frontend.h.
 */
object Snes {
    const val B = 1 shl 15
    const val Y = 1 shl 14
    const val SELECT = 1 shl 13
    const val START = 1 shl 12
    const val UP = 1 shl 11
    const val DOWN = 1 shl 10
    const val LEFT = 1 shl 9
    const val RIGHT = 1 shl 8
    const val A = 1 shl 7
    const val X = 1 shl 6
    const val L = 1 shl 5
    const val R = 1 shl 4
}

/** Botão virtual em coordenadas normalizadas (0..1) para funcionar em qualquer tela. */
private class VButton(val mask: Int, val label: String, val cx: Float, val cy: Float, val r: Float)

/** Layout do pad virtual + hit-test. Raio normalizado pela menor dimensão da view. */
private class VirtualPad {
    var w = 1f
    var h = 1f
    val buttons = listOf(
        // D-pad (esquerda)
        VButton(Snes.UP, "▲", 0.13f, 0.52f, 0.075f),
        VButton(Snes.DOWN, "▼", 0.13f, 0.84f, 0.075f),
        VButton(Snes.LEFT, "◀", 0.06f, 0.68f, 0.075f),
        VButton(Snes.RIGHT, "▶", 0.20f, 0.68f, 0.075f),
        // Botões de ação (direita)
        VButton(Snes.A, "A", 0.94f, 0.68f, 0.085f),
        VButton(Snes.B, "B", 0.85f, 0.82f, 0.085f),
        VButton(Snes.X, "X", 0.85f, 0.54f, 0.085f),
        VButton(Snes.Y, "Y", 0.76f, 0.68f, 0.085f),
        // Ombros e menu
        VButton(Snes.L, "L", 0.07f, 0.18f, 0.08f),
        VButton(Snes.R, "R", 0.93f, 0.18f, 0.08f),
        VButton(Snes.SELECT, "SEL", 0.42f, 0.92f, 0.055f),
        VButton(Snes.START, "START", 0.58f, 0.92f, 0.055f),
    )

    /** Botão "ROM" no topo: abre o seletor de jogo (não gera input do SNES). */
    val menu = VButton(0, "ROM", 0.5f, 0.08f, 0.05f)

    fun radiusPx(b: VButton) = b.r * minOf(w, h)

    private fun inside(b: VButton, x: Float, y: Float, scale: Float): Boolean {
        val dx = x - b.cx * w
        val dy = y - b.cy * h
        val rr = radiusPx(b) * scale
        return dx * dx + dy * dy <= rr * rr
    }

    fun isMenu(x: Float, y: Float) = inside(menu, x, y, 1.2f)

    /** Retorna a máscara de todos os botões sob o ponto (permite deslizar entre botões). */
    fun hit(x: Float, y: Float): Int {
        var m = 0
        for (b in buttons) if (inside(b, x, y, 1.25f)) m = m or b.mask
        return m
    }
}

/** Overlay que só desenha os botões (não consome toques: eles chegam à Activity). */
private class PadOverlay(ctx: Context, private val pad: VirtualPad) : View(ctx) {
    var pressed = 0
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        pad.w = w.toFloat(); pad.h = h.toFloat()
    }

    private fun drawButton(c: Canvas, b: VButton, on: Boolean) {
        fill.color = if (on) 0xAAFFFFFF.toInt() else 0x44FFFFFF
        val r = pad.radiusPx(b)
        c.drawCircle(b.cx * width, b.cy * height, r, fill)
        text.textSize = r * 0.7f
        c.drawText(b.label, b.cx * width, b.cy * height + r * 0.25f, text)
    }

    override fun onDraw(c: Canvas) {
        for (b in pad.buttons) drawButton(c, b, (pressed and b.mask) != 0)
        drawButton(c, pad.menu, false)
    }
}

class MainActivity : AppCompatActivity(), SurfaceHolder.Callback {

    // --- Ponte JNI ---------------------------------------------------------
    // Cada "external fun" corresponde a Java_com_example_topgear_MainActivity_<nome>
    // em native-lib.cpp. Tipos: Int->jint, String->jstring, ByteArray->jbyteArray.
    private external fun nativeInit(systemDir: String, saveDir: String): Boolean
    private external fun nativeLoadRom(rom: ByteArray): Boolean
    private external fun nativeSetSurface(surface: android.view.Surface?)
    private external fun nativeSetInput(mask: Int)
    private external fun nativeStart()
    private external fun nativeStop()
    private external fun nativeDestroy()

    companion object {
        init {
            // Carrega libtopgear.so (nome definido em add_library no CMakeLists.txt)
            System.loadLibrary("topgear")
        }
        private const val PREFS = "topgear"
        private const val KEY_ROM = "rom_uri"
    }

    private val pad = VirtualPad()
    private lateinit var overlay: PadOverlay
    private lateinit var surfaceView: SurfaceView
    private var touchMask = 0
    private var keyMask = 0
    private var lastSent = -1
    private var romLoaded = false
    private var surfaceReady = false

    // Seletor de ROM (Storage Access Framework): o usuário escolhe a própria ROM.
    private val pickRom = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                // Guarda a permissão para reabrir a mesma ROM automaticamente nas próximas vezes.
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: SecurityException) { /* provedor não oferece permissão persistente */ }
            if (loadRom(uri)) {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_ROM, uri.toString()).apply()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        enterImmersive()

        surfaceView = SurfaceView(this).apply { holder.addCallback(this@MainActivity) }
        overlay = PadOverlay(this, pad)

        val root = FrameLayout(this)
        val mp = ViewGroup.LayoutParams.MATCH_PARENT
        root.addView(surfaceView, FrameLayout.LayoutParams(mp, mp, Gravity.CENTER))
        root.addView(overlay, FrameLayout.LayoutParams(mp, mp))
        // Mantém a imagem em 4:3 (proporção de tela do SNES), centralizada.
        root.addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ -> fitSurface(r - l, b - t) }
        setContentView(root)

        val dir = filesDir.absolutePath
        nativeInit(dir, dir)

        // Plug and play: reabre a última ROM; só pede o arquivo na primeira vez.
        val saved = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_ROM, null)
        if (saved == null || !loadRom(Uri.parse(saved))) {
            pickRom.launch(arrayOf("*/*"))
        }
    }

    private fun fitSurface(w: Int, h: Int) {
        if (w <= 0 || h <= 0) return
        var sw = w
        var sh = (w * 3f / 4f).toInt()
        if (sh > h) { sh = h; sw = (h * 4f / 3f).toInt() }
        val lp = surfaceView.layoutParams as FrameLayout.LayoutParams
        if (lp.width != sw || lp.height != sh) {
            lp.width = sw; lp.height = sh; lp.gravity = Gravity.CENTER
            surfaceView.layoutParams = lp
        }
    }

    private fun loadRom(uri: Uri): Boolean {
        nativeStop()
        val bytes = try {
            contentResolver.openInputStream(uri)?.use { it.readBytes() }
        } catch (_: Exception) { null }
        romLoaded = bytes != null && nativeLoadRom(bytes)
        if (!romLoaded) {
            Toast.makeText(this, "Não foi possível abrir essa ROM", Toast.LENGTH_LONG).show()
            return false
        }
        if (surfaceReady) nativeStart()
        return true
    }

    /**
     * Captura multitoque. Reconstruímos a máscara completa a cada evento a partir
     * de todos os ponteiros ativos; assim, soltar um dedo nunca deixa botão preso.
     */
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN && pad.isMenu(e.x, e.y)) {
            pickRom.launch(arrayOf("*/*"))
            return true
        }
        touchMask = when (e.actionMasked) {
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> 0
            else -> {
                var m = 0
                for (i in 0 until e.pointerCount) {
                    // O ponteiro que acabou de subir ainda aparece neste evento.
                    if (e.actionMasked == MotionEvent.ACTION_POINTER_UP && i == e.actionIndex) continue
                    m = m or pad.hit(e.getX(i), e.getY(i))
                }
                m
            }
        }
        sendInput()
        return true
    }

    /** Controle físico (Bluetooth/USB) e teclado: layout posicional do Xbox -> SNES. */
    private fun keyToMask(code: Int): Int = when (code) {
        KeyEvent.KEYCODE_BUTTON_A -> Snes.B
        KeyEvent.KEYCODE_BUTTON_B -> Snes.A
        KeyEvent.KEYCODE_BUTTON_X -> Snes.Y
        KeyEvent.KEYCODE_BUTTON_Y -> Snes.X
        KeyEvent.KEYCODE_BUTTON_L1 -> Snes.L
        KeyEvent.KEYCODE_BUTTON_R1 -> Snes.R
        KeyEvent.KEYCODE_BUTTON_START -> Snes.START
        KeyEvent.KEYCODE_BUTTON_SELECT -> Snes.SELECT
        KeyEvent.KEYCODE_DPAD_UP -> Snes.UP
        KeyEvent.KEYCODE_DPAD_DOWN -> Snes.DOWN
        KeyEvent.KEYCODE_DPAD_LEFT -> Snes.LEFT
        KeyEvent.KEYCODE_DPAD_RIGHT -> Snes.RIGHT
        else -> 0
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        val m = keyToMask(keyCode)
        if (m == 0) return super.onKeyDown(keyCode, event)
        keyMask = keyMask or m
        sendInput()
        return true
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        val m = keyToMask(keyCode)
        if (m == 0) return super.onKeyUp(keyCode, event)
        keyMask = keyMask and m.inv()
        sendInput()
        return true
    }

    /** Junta toque + controle e só chama o JNI quando a máscara muda. */
    private fun sendInput() {
        val mask = touchMask or keyMask
        if (mask != lastSent) {
            lastSent = mask
            nativeSetInput(mask)          // -> frontend -> snes9x -> $4218/$4219
            overlay.pressed = mask
            overlay.invalidate()
        }
    }

    // --- SurfaceHolder.Callback --------------------------------------------
    override fun surfaceCreated(holder: SurfaceHolder) {
        nativeSetSurface(holder.surface)
        surfaceReady = true
        if (romLoaded) nativeStart()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) = Unit

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        surfaceReady = false
        nativeStop()
        nativeSetSurface(null)
    }

    override fun onPause() {
        super.onPause()
        nativeStop()                      // também grava o save do jogo
        touchMask = 0; keyMask = 0
        sendInput()
    }

    override fun onResume() {
        super.onResume()
        enterImmersive()
        if (romLoaded && surfaceReady) nativeStart()
    }

    override fun onDestroy() {
        nativeDestroy()
        super.onDestroy()
    }

    private fun enterImmersive() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }
}
