// native-lib.cpp — ponte JNI entre a UI Kotlin e o frontend libretro (snes9x).
//
// Fluxo:
//   Kotlin (MainActivity) --JNI--> Java_com_example_topgear_MainActivity_*
//     nativeInit(sysDir, saveDir)  : inicializa o core snes9x
//     nativeLoadRom(bytes)         : carrega ROM + SRAM
//     nativeSetSurface(surface)    : Surface -> ANativeWindow (vídeo)
//     nativeSetInput(mask)         : máscara do pad virtual -> $4218/$4219
//     nativeStart / nativeStop     : thread de emulação + áudio (Oboe)
//
// O nome de cada função JNI segue: Java_<pacote com _>_<Classe>_<método>.
// Se mudar o pacote ou a classe no Kotlin, renomeie as funções aqui.

#include <jni.h>
#include <android/log.h>
#include <android/native_window.h>
#include <android/native_window_jni.h>

#include <cstring>   // antes do Oboe: alguns cabeçalhos dele usam memset sem incluir

#include <oboe/Oboe.h>

#include <atomic>
#include <chrono>
#include <memory>
#include <mutex>
#include <string>
#include <thread>

#include "frontend.h"

#define LOG_TAG "TopGearNative"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace {

std::atomic<bool> g_running{false};
std::thread       g_thread;

std::mutex      g_winMutex;       // protege g_window (surface destroy vs. blit)
ANativeWindow*  g_window = nullptr;
int             g_lastW = 0, g_lastH = 0;

std::shared_ptr<oboe::AudioStream> g_stream;

// ---------------------------------------------------------------------------
// Áudio (Oboe): o callback puxa do ring buffer do frontend. Sem locks nem alocação.
// ---------------------------------------------------------------------------
class AudioCallback final : public oboe::AudioStreamDataCallback {
public:
    oboe::DataCallbackResult onAudioReady(oboe::AudioStream*, void* audioData,
                                          int32_t numFrames) override {
        auto* out = static_cast<int16_t*>(audioData);
        const size_t got = fe::readAudio(out, static_cast<size_t>(numFrames));
        if (got < static_cast<size_t>(numFrames))        // underrun: completa com silêncio
            std::memset(out + got * 2, 0, (static_cast<size_t>(numFrames) - got) * 2 * sizeof(int16_t));
        return oboe::DataCallbackResult::Continue;
    }
};

void startAudio(int sampleRate) {
    oboe::AudioStreamBuilder b;
    b.setDirection(oboe::Direction::Output)
        ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
        ->setSharingMode(oboe::SharingMode::Shared)
        ->setFormat(oboe::AudioFormat::I16)
        ->setChannelCount(oboe::ChannelCount::Stereo)
        ->setSampleRate(sampleRate)                       // 32040 Hz do SPC700
        ->setSampleRateConversionQuality(oboe::SampleRateConversionQuality::Medium)
        ->setUsage(oboe::Usage::Game)
        ->setDataCallback(std::make_shared<AudioCallback>());
    const oboe::Result r = b.openStream(g_stream);
    if (r != oboe::Result::OK) { LOGE("Oboe openStream: %s", oboe::convertToText(r)); g_stream.reset(); return; }
    g_stream->requestStart();
}

void stopAudio() {
    if (g_stream) { g_stream->stop(); g_stream->close(); g_stream.reset(); }
}

// ---------------------------------------------------------------------------
// Vídeo: copia o RGBA do core para a Surface. O tamanho do buffer segue o do core
// (256x224, 512x448 em alta resolução, 256x239 PAL...); o compositor escala.
// ---------------------------------------------------------------------------
void blit(const fe::Video& v) {
    if (!v.rgba || v.width <= 0 || v.height <= 0) return;
    std::lock_guard<std::mutex> lk(g_winMutex);
    if (!g_window) return;
    if (v.width != g_lastW || v.height != g_lastH) {
        ANativeWindow_setBuffersGeometry(g_window, v.width, v.height, WINDOW_FORMAT_RGBA_8888);
        g_lastW = v.width;
        g_lastH = v.height;
    }
    ANativeWindow_Buffer buf;
    if (ANativeWindow_lock(g_window, &buf, nullptr) != 0) return;
    auto* dst = static_cast<uint32_t*>(buf.bits);
    const int rows = buf.height < v.height ? buf.height : v.height;
    const int cols = buf.width  < v.width  ? buf.width  : v.width;
    for (int y = 0; y < rows; ++y)
        std::memcpy(dst + static_cast<size_t>(y) * buf.stride,
                    v.rgba + static_cast<size_t>(y) * v.width,
                    static_cast<size_t>(cols) * sizeof(uint32_t));
    ANativeWindow_unlockAndPost(g_window);
}

void emulationLoop() {
    using clock = std::chrono::steady_clock;
    const auto period = std::chrono::duration_cast<clock::duration>(
        std::chrono::duration<double>(1.0 / fe::fps()));     // ~16,64 ms (NTSC)
    auto next = clock::now();
    while (g_running.load(std::memory_order_acquire)) {
        fe::runFrame();
        const fe::Video v = fe::video();
        if (v.updated) blit(v);
        next += period;
        std::this_thread::sleep_until(next);
        // Se atrasou muito (app pausado, CPU ocupada), ressincroniza em vez de acelerar.
        if (clock::now() - next > std::chrono::milliseconds(100)) next = clock::now();
    }
}

void stopAll() {
    g_running.store(false, std::memory_order_release);
    if (g_thread.joinable()) g_thread.join();
    stopAudio();
    fe::flushSram();   // grava o save do jogo sempre que a emulação para
}

void androidLog(int level, const char* msg) {
    static const int prio[] = {ANDROID_LOG_DEBUG, ANDROID_LOG_INFO, ANDROID_LOG_WARN, ANDROID_LOG_ERROR};
    __android_log_print(prio[level < 0 ? 0 : (level > 3 ? 3 : level)], "snes9x", "%s", msg);
}

std::string jstr(JNIEnv* env, jstring s) {
    if (!s) return {};
    const char* c = env->GetStringUTFChars(s, nullptr);
    std::string out = c ? c : "";
    if (c) env->ReleaseStringUTFChars(s, c);
    return out;
}

} // namespace

// ---------------------------------------------------------------------------
// Funções JNI (MainActivity.kt: external fun ...)
// Tipos: Int->jint, Boolean->jboolean, String->jstring, ByteArray->jbyteArray.
// ---------------------------------------------------------------------------
extern "C" {

JNIEXPORT jboolean JNICALL
Java_com_example_topgear_MainActivity_nativeInit(JNIEnv* env, jobject, jstring sysDir, jstring saveDir) {
    fe::setLogger(androidLog);
    const bool ok = fe::init(jstr(env, sysDir), jstr(env, saveDir));
    LOGI("Core snes9x inicializado: %d", ok);
    return ok ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL
Java_com_example_topgear_MainActivity_nativeLoadRom(JNIEnv* env, jobject, jbyteArray rom) {
    if (!rom) return JNI_FALSE;
    stopAll();                                   // nunca troca a ROM com a emulação rodando
    const jsize len = env->GetArrayLength(rom);
    // GetByteArrayElements pode copiar; JNI_ABORT descarta a cópia sem escrever de volta.
    jbyte* bytes = env->GetByteArrayElements(rom, nullptr);
    if (!bytes) return JNI_FALSE;
    const bool ok = fe::loadGame(reinterpret_cast<const uint8_t*>(bytes), static_cast<size_t>(len));
    env->ReleaseByteArrayElements(rom, bytes, JNI_ABORT);
    if (!ok) LOGE("Falha ao carregar ROM (%d bytes)", static_cast<int>(len));
    return ok ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_example_topgear_MainActivity_nativeSetSurface(JNIEnv* env, jobject, jobject surface) {
    std::lock_guard<std::mutex> lk(g_winMutex);
    if (g_window) { ANativeWindow_release(g_window); g_window = nullptr; }
    g_lastW = g_lastH = 0;                       // força reaplicar o tamanho do buffer
    if (surface) g_window = ANativeWindow_fromSurface(env, surface);
}

// Chamada a cada mudança de toque: só um store atômico (sem locks nem alocação),
// seguro para a thread de UI. O snes9x lê a máscara em input_state() e gera
// $4218/$4219 na leitura automática do joypad.
JNIEXPORT void JNICALL
Java_com_example_topgear_MainActivity_nativeSetInput(JNIEnv*, jobject, jint mask) {
    fe::setPad(static_cast<uint16_t>(mask));
}

JNIEXPORT void JNICALL
Java_com_example_topgear_MainActivity_nativeStart(JNIEnv*, jobject) {
    if (!fe::gameLoaded()) return;
    if (g_running.exchange(true)) return;
    startAudio(fe::sampleRate());
    g_thread = std::thread(emulationLoop);
}

JNIEXPORT void JNICALL
Java_com_example_topgear_MainActivity_nativeStop(JNIEnv*, jobject) {
    stopAll();
}

JNIEXPORT void JNICALL
Java_com_example_topgear_MainActivity_nativeDestroy(JNIEnv*, jobject) {
    stopAll();
    fe::shutdown();
}

} // extern "C"
