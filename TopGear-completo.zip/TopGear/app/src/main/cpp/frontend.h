// frontend.h — frontend libretro portátil (sem dependências de Android).
//
// Fica entre o core snes9x (API libretro: retro_*) e a camada Android (native-lib.cpp):
//   - recebe o vídeo do core e converte para RGBA8888
//   - recebe o áudio do core e guarda num ring buffer lock-free (SPSC)
//   - entrega ao core o estado dos botões (input_state)
//   - carrega e grava a SRAM (saves do jogo) em disco
//
// Por não depender de Android, o mesmo código roda no teste de host (host_test.cpp).
#pragma once

#include <cstddef>
#include <cstdint>
#include <string>

namespace fe {

// Máscara do pad no formato do SNES: palavra de 16 bits = ($4219 << 8) | $4218.
//   $4218 JOY1L: bit7=A bit6=X bit5=L bit4=R   (bits 3-0 = 0)
//   $4219 JOY1H: bit7=B bit6=Y bit5=Select bit4=Start bit3=Up bit2=Down bit1=Left bit0=Right
// O snes9x lê estes botões via input_state e produz $4218/$4219 na leitura
// automática do joypad (NMITIMEN $4200 bit 0), exatamente como o hardware.
constexpr uint16_t BTN_B      = 1u << 15;
constexpr uint16_t BTN_Y      = 1u << 14;
constexpr uint16_t BTN_SELECT = 1u << 13;
constexpr uint16_t BTN_START  = 1u << 12;
constexpr uint16_t BTN_UP     = 1u << 11;
constexpr uint16_t BTN_DOWN   = 1u << 10;
constexpr uint16_t BTN_LEFT   = 1u << 9;
constexpr uint16_t BTN_RIGHT  = 1u << 8;
constexpr uint16_t BTN_A      = 1u << 7;
constexpr uint16_t BTN_X      = 1u << 6;
constexpr uint16_t BTN_L      = 1u << 5;
constexpr uint16_t BTN_R      = 1u << 4;

// Níveis: 0=debug 1=info 2=warn 3=error (mesmos do libretro).
using LogFn = void (*)(int level, const char* msg);
void setLogger(LogFn fn);

bool init(const std::string& systemDir, const std::string& saveDir);
void shutdown();

// Carrega a ROM (com ou sem header de copiador; o snes9x detecta sozinho).
// Também carrega a SRAM salva anteriormente para esta ROM.
bool loadGame(const uint8_t* data, size_t size);
bool gameLoaded();

void setPad(uint16_t mask);   // seguro de qualquer thread
void runFrame();              // executa 1 frame de emulação

struct Video {
    const uint32_t* rgba;     // RGBA8888 (bytes na memória: R,G,B,A)
    int width;
    int height;
    bool updated;             // houve frame novo neste runFrame()
};
Video video();

int    sampleRate();          // normalmente 32040 Hz
double fps();                 // ~60,0988 (NTSC) ou ~50,0070 (PAL)

// Consumidor de áudio (thread do Oboe). Copia até `frames` quadros estéreo int16
// intercalados; retorna quantos copiou. Lock-free.
size_t readAudio(int16_t* dst, size_t frames);

void flushSram();             // grava a SRAM em disco se mudou

} // namespace fe
