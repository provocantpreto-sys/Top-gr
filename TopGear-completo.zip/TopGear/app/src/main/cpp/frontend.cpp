// frontend.cpp — implementação do frontend libretro (veja frontend.h).

#include "frontend.h"

#include "libretro.h"

#include <algorithm>
#include <atomic>
#include <cstdarg>
#include <cstdio>
#include <cstring>
#include <vector>

namespace fe {
namespace {

// ---------------------------------------------------------------------------
// Estado
// ---------------------------------------------------------------------------
LogFn g_log = nullptr;

std::string g_sysDir, g_saveDir, g_srmPath;
retro_pixel_format g_fmt = RETRO_PIXEL_FORMAT_0RGB1555;  // padrão do libretro
bool g_inited = false;
bool g_loaded = false;
std::vector<uint8_t> g_romCopy;

std::atomic<uint16_t> g_mask{0};

double g_fps = 60.0988;
int    g_rate = 32040;

std::vector<uint32_t> g_rgba;
int  g_vw = 0, g_vh = 0;
bool g_updated = false;

// Ring buffer de áudio (potência de 2), produtor = thread de emulação,
// consumidor = thread de áudio. Índices monotônicos de 64 bits.
constexpr size_t RING_FRAMES = 1u << 14;   // ~0,5 s a 32 kHz
constexpr size_t RING_MASK   = RING_FRAMES - 1;
std::vector<int16_t>  g_ring;
std::atomic<uint64_t> g_wr{0};
std::atomic<uint64_t> g_rd{0};

std::vector<uint8_t> g_sramShadow;
uint32_t g_frameCount = 0;

void logMsg(int level, const char* msg) {
    if (g_log) g_log(level, msg);
    else std::fprintf(stderr, "[fe:%d] %s", level, msg);
}

// ---------------------------------------------------------------------------
// Callbacks libretro
// ---------------------------------------------------------------------------
void RETRO_CALLCONV cbLog(enum retro_log_level level, const char* fmt, ...) {
    char buf[1024];
    va_list ap;
    va_start(ap, fmt);
    std::vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    logMsg(static_cast<int>(level), buf);
}

bool RETRO_CALLCONV cbEnvironment(unsigned cmd, void* data) {
    switch (cmd) {
        case RETRO_ENVIRONMENT_GET_CAN_DUPE:
            *static_cast<bool*>(data) = true;           // aceita frames repetidos (data == NULL)
            return true;
        case RETRO_ENVIRONMENT_SET_PIXEL_FORMAT: {
            const auto f = *static_cast<const retro_pixel_format*>(data);
            if (f == RETRO_PIXEL_FORMAT_XRGB8888 || f == RETRO_PIXEL_FORMAT_RGB565 ||
                f == RETRO_PIXEL_FORMAT_0RGB1555) {
                g_fmt = f;
                return true;
            }
            return false;
        }
        case RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY:
        case RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY:
            *static_cast<const char**>(data) =
                (cmd == RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY ? g_sysDir : g_saveDir).c_str();
            return true;
        case RETRO_ENVIRONMENT_GET_LOG_INTERFACE:
            static_cast<retro_log_callback*>(data)->log = cbLog;
            return true;
        case RETRO_ENVIRONMENT_GET_VARIABLE:
            static_cast<retro_variable*>(data)->value = nullptr;  // usa os padrões do core
            return false;
        case RETRO_ENVIRONMENT_GET_VARIABLE_UPDATE:
            *static_cast<bool*>(data) = false;
            return true;
        case RETRO_ENVIRONMENT_GET_AUDIO_VIDEO_ENABLE:
            *static_cast<int*>(data) = 3;               // vídeo + áudio ligados
            return true;
        case RETRO_ENVIRONMENT_SET_GEOMETRY:
        case RETRO_ENVIRONMENT_SET_INPUT_DESCRIPTORS:
        case RETRO_ENVIRONMENT_SET_CONTROLLER_INFO:
        case RETRO_ENVIRONMENT_SET_PERFORMANCE_LEVEL:
        case RETRO_ENVIRONMENT_SET_SUPPORT_ACHIEVEMENTS:
        case RETRO_ENVIRONMENT_SET_SUBSYSTEM_INFO:
        case RETRO_ENVIRONMENT_SET_CORE_OPTIONS_DISPLAY:
            return true;
        default:
            return false;
    }
}

inline uint32_t pack(uint32_t r, uint32_t g, uint32_t b) {
    return 0xFF000000u | (b << 16) | (g << 8) | r;     // bytes: R,G,B,A (little-endian)
}

void RETRO_CALLCONV cbVideo(const void* data, unsigned w, unsigned h, size_t pitch) {
    if (!data) { g_updated = true; return; }           // frame repetido: mantém o buffer
    if (w == 0 || h == 0 || w > 1024 || h > 1024) return;

    g_vw = static_cast<int>(w);
    g_vh = static_cast<int>(h);
    g_rgba.resize(static_cast<size_t>(w) * h);

    const auto* src = static_cast<const uint8_t*>(data);
    for (unsigned y = 0; y < h; ++y) {
        uint32_t* dst = &g_rgba[static_cast<size_t>(y) * w];
        const uint8_t* row = src + y * pitch;
        switch (g_fmt) {
            case RETRO_PIXEL_FORMAT_XRGB8888: {
                const auto* p = reinterpret_cast<const uint32_t*>(row);
                for (unsigned x = 0; x < w; ++x)
                    dst[x] = pack((p[x] >> 16) & 0xFF, (p[x] >> 8) & 0xFF, p[x] & 0xFF);
                break;
            }
            case RETRO_PIXEL_FORMAT_RGB565: {
                const auto* p = reinterpret_cast<const uint16_t*>(row);
                for (unsigned x = 0; x < w; ++x) {
                    const uint32_t v = p[x];
                    const uint32_t r = (v >> 11) & 31, g = (v >> 5) & 63, b = v & 31;
                    dst[x] = pack((r << 3) | (r >> 2), (g << 2) | (g >> 4), (b << 3) | (b >> 2));
                }
                break;
            }
            default: {                                   // 0RGB1555
                const auto* p = reinterpret_cast<const uint16_t*>(row);
                for (unsigned x = 0; x < w; ++x) {
                    const uint32_t v = p[x];
                    const uint32_t r = (v >> 10) & 31, g = (v >> 5) & 31, b = v & 31;
                    dst[x] = pack((r << 3) | (r >> 2), (g << 3) | (g >> 2), (b << 3) | (b >> 2));
                }
                break;
            }
        }
    }
    g_updated = true;
}

size_t RETRO_CALLCONV cbAudioBatch(const int16_t* data, size_t frames) {
    const uint64_t w = g_wr.load(std::memory_order_relaxed);
    const uint64_t r = g_rd.load(std::memory_order_acquire);
    const size_t space = RING_FRAMES - static_cast<size_t>(w - r);
    const size_t n = std::min(frames, space);          // se encher, descarta o excedente
    for (size_t i = 0; i < n; ++i) {
        const size_t idx = static_cast<size_t>((w + i) & RING_MASK) * 2;
        g_ring[idx]     = data[i * 2];
        g_ring[idx + 1] = data[i * 2 + 1];
    }
    g_wr.store(w + n, std::memory_order_release);
    return frames;
}

void RETRO_CALLCONV cbAudioSample(int16_t l, int16_t r) {
    const int16_t s[2] = {l, r};
    cbAudioBatch(s, 1);
}

void RETRO_CALLCONV cbInputPoll() {}

// Ordem dos ids do joypad libretro -> bits do SNES.
constexpr uint16_t kJoyBit[12] = {
    BTN_B, BTN_Y, BTN_SELECT, BTN_START, BTN_UP, BTN_DOWN,
    BTN_LEFT, BTN_RIGHT, BTN_A, BTN_X, BTN_L, BTN_R,
};

int16_t RETRO_CALLCONV cbInputState(unsigned port, unsigned device, unsigned /*index*/, unsigned id) {
    if (port != 0 || (device & RETRO_DEVICE_MASK) != RETRO_DEVICE_JOYPAD) return 0;
    uint16_t m = g_mask.load(std::memory_order_relaxed);
    // D-pad físico nunca tem direções opostas ao mesmo tempo.
    if ((m & BTN_UP) && (m & BTN_DOWN))    m &= ~(BTN_UP | BTN_DOWN);
    if ((m & BTN_LEFT) && (m & BTN_RIGHT)) m &= ~(BTN_LEFT | BTN_RIGHT);
    if (id == RETRO_DEVICE_ID_JOYPAD_MASK) {
        int16_t out = 0;
        for (unsigned i = 0; i < 12; ++i) if (m & kJoyBit[i]) out |= static_cast<int16_t>(1u << i);
        return out;
    }
    if (id >= 12) return 0;
    return (m & kJoyBit[id]) ? 1 : 0;
}

// ---------------------------------------------------------------------------
// SRAM
// ---------------------------------------------------------------------------
std::string hashName(const uint8_t* d, size_t n) {
    uint64_t h = 1469598103934665603ULL;               // FNV-1a 64 bits
    for (size_t i = 0; i < n; ++i) { h ^= d[i]; h *= 1099511628211ULL; }
    char buf[32];
    std::snprintf(buf, sizeof(buf), "%016llx", static_cast<unsigned long long>(h));
    return buf;
}

void loadSram() {
    void* p = retro_get_memory_data(RETRO_MEMORY_SAVE_RAM);
    const size_t n = retro_get_memory_size(RETRO_MEMORY_SAVE_RAM);
    g_sramShadow.clear();
    if (!p || n == 0) return;
    if (FILE* f = std::fopen(g_srmPath.c_str(), "rb")) {
        const size_t got = std::fread(p, 1, n, f);
        std::fclose(f);
        logMsg(1, "SRAM carregada\n");
        (void)got;
    }
    g_sramShadow.assign(static_cast<uint8_t*>(p), static_cast<uint8_t*>(p) + n);
}

} // namespace

// ---------------------------------------------------------------------------
// API pública
// ---------------------------------------------------------------------------
void setLogger(LogFn fn) { g_log = fn; }

bool init(const std::string& systemDir, const std::string& saveDir) {
    if (g_inited) return true;
    g_sysDir = systemDir;
    g_saveDir = saveDir;
    g_ring.assign(RING_FRAMES * 2, 0);

    // Ordem exigida pelo libretro: environment antes de retro_init.
    retro_set_environment(cbEnvironment);
    retro_init();
    retro_set_video_refresh(cbVideo);
    retro_set_audio_sample(cbAudioSample);
    retro_set_audio_sample_batch(cbAudioBatch);
    retro_set_input_poll(cbInputPoll);
    retro_set_input_state(cbInputState);
    g_inited = true;
    return true;
}

void flushSram() {
    if (!g_loaded) return;
    void* p = retro_get_memory_data(RETRO_MEMORY_SAVE_RAM);
    const size_t n = retro_get_memory_size(RETRO_MEMORY_SAVE_RAM);
    if (!p || n == 0) return;
    if (g_sramShadow.size() == n && std::memcmp(g_sramShadow.data(), p, n) == 0) return;
    const std::string tmp = g_srmPath + ".tmp";
    if (FILE* f = std::fopen(tmp.c_str(), "wb")) {
        const size_t wrote = std::fwrite(p, 1, n, f);
        std::fclose(f);
        if (wrote == n && std::rename(tmp.c_str(), g_srmPath.c_str()) == 0)
            g_sramShadow.assign(static_cast<uint8_t*>(p), static_cast<uint8_t*>(p) + n);
    }
}

void shutdown() {
    if (g_loaded) { flushSram(); retro_unload_game(); g_loaded = false; }
    if (g_inited) { retro_deinit(); g_inited = false; }
}

bool loadGame(const uint8_t* data, size_t size) {
    if (!g_inited || !data || size < 0x8000) return false;
    if (g_loaded) { flushSram(); retro_unload_game(); g_loaded = false; }

    g_romCopy.assign(data, data + size);
    g_srmPath = g_saveDir + "/" + hashName(data, size) + ".srm";
    g_wr.store(0); g_rd.store(0);
    g_vw = g_vh = 0;
    g_updated = false;
    g_frameCount = 0;

    retro_game_info info{};
    info.path = "game.sfc";
    info.data = g_romCopy.data();
    info.size = g_romCopy.size();
    info.meta = nullptr;
    if (!retro_load_game(&info)) { logMsg(3, "retro_load_game falhou\n"); return false; }
    g_loaded = true;

    retro_system_av_info av{};
    retro_get_system_av_info(&av);
    if (av.timing.fps > 20.0 && av.timing.fps < 120.0) g_fps = av.timing.fps;
    if (av.timing.sample_rate > 8000.0) g_rate = static_cast<int>(av.timing.sample_rate + 0.5);

    loadSram();
    return true;
}

bool gameLoaded() { return g_loaded; }

void setPad(uint16_t mask) { g_mask.store(mask, std::memory_order_relaxed); }

void runFrame() {
    if (!g_loaded) return;
    g_updated = false;
    retro_run();
    if (++g_frameCount % 1800 == 0) flushSram();       // ~30 s: grava saves automaticamente
}

Video video() { return Video{g_rgba.empty() ? nullptr : g_rgba.data(), g_vw, g_vh, g_updated}; }

int sampleRate() { return g_rate; }
double fps() { return g_fps; }

size_t readAudio(int16_t* dst, size_t frames) {
    const uint64_t r = g_rd.load(std::memory_order_relaxed);
    const uint64_t w = g_wr.load(std::memory_order_acquire);
    const size_t n = std::min(frames, static_cast<size_t>(w - r));
    for (size_t i = 0; i < n; ++i) {
        const size_t idx = static_cast<size_t>((r + i) & RING_MASK) * 2;
        dst[i * 2]     = g_ring[idx];
        dst[i * 2 + 1] = g_ring[idx + 1];
    }
    g_rd.store(r + n, std::memory_order_release);
    return n;
}

} // namespace fe
