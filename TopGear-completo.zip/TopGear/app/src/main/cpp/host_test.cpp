// host_test.cpp — teste de ponta a ponta no computador (sem Android).
// Monta um mini-ROM SNES (escrito em código de máquina 65c816) que mostra uma cor
// de fundo vermelha, e verde enquanto o botão B estiver pressionado. Valida:
// carga da ROM pelo snes9x, vídeo, áudio, taxa de quadros e mapeamento de entrada.
//
// Compilar: cmake -S . -B build -DTOPGEAR_HOST_TEST=ON && cmake --build build && ./build/host_test

#include "frontend.h"

#include <cstdio>
#include <cstdlib>
#include <vector>

static std::vector<uint8_t> makeRom() {
    std::vector<uint8_t> rom(0x8000, 0xFF);

    const uint8_t code[] = {
        0x78,                       // 00  SEI
        0x18,                       // 01  CLC
        0xFB,                       // 02  XCE            (modo nativo)
        0xA9, 0x8F,                 // 03  LDA #$8F
        0x8D, 0x00, 0x21,           // 05  STA $2100      (forced blank)
        0xA9, 0x01,                 // 08  LDA #$01
        0x8D, 0x00, 0x42,           // 0A  STA $4200      (auto-joypad read ligado)
        0x9C, 0x2C, 0x21,           // 0D  STZ $212C      (nenhuma BG: só a cor de fundo)
        0xA9, 0x0F,                 // 10  LDA #$0F
        0x8D, 0x00, 0x21,           // 12  STA $2100      (tela ligada)
        // L0 (0x15): espera sair do VBlank
        0xAD, 0x12, 0x42,           // 15  LDA $4212
        0x30, 0xFB,                 // 18  BMI L0
        // L1 (0x1A): espera entrar no VBlank
        0xAD, 0x12, 0x42,           // 1A  LDA $4212
        0x10, 0xFB,                 // 1D  BPL L1
        // L2 (0x1F): espera terminar a leitura automática do joypad
        0xAD, 0x12, 0x42,           // 1F  LDA $4212
        0x29, 0x01,                 // 22  AND #$01
        0xD0, 0xF9,                 // 24  BNE L2
        0xAD, 0x19, 0x42,           // 26  LDA $4219      (JOY1H: bit7 = B)
        0x10, 0x0F,                 // 29  BPL notB
        // B pressionado: fundo verde ($03E0)
        0x9C, 0x21, 0x21,           // 2B  STZ $2121
        0xA9, 0xE0,                 // 2E  LDA #$E0
        0x8D, 0x22, 0x21,           // 30  STA $2122
        0xA9, 0x03,                 // 33  LDA #$03
        0x8D, 0x22, 0x21,           // 35  STA $2122
        0x80, 0x0D,                 // 38  BRA end
        // notB: fundo vermelho ($001F)
        0x9C, 0x21, 0x21,           // 3A  STZ $2121
        0xA9, 0x1F,                 // 3D  LDA #$1F
        0x8D, 0x22, 0x21,           // 3F  STA $2122
        0xA9, 0x00,                 // 42  LDA #$00
        0x8D, 0x22, 0x21,           // 44  STA $2122
        // end (0x47):
        0x80, 0xCC,                 // 47  BRA L0
    };
    for (size_t i = 0; i < sizeof(code); ++i) rom[i] = code[i];

    // Header LoROM em 0x7FC0
    const char title[] = "TOPGEAR HOST TEST     ";
    for (int i = 0; i < 21; ++i) rom[0x7FC0 + i] = static_cast<uint8_t>(title[i]);
    rom[0x7FD5] = 0x20;  // LoROM
    rom[0x7FD6] = 0x00;
    rom[0x7FD7] = 0x05;  // 32 KB
    rom[0x7FD8] = 0x00;
    rom[0x7FD9] = 0x01;  // NTSC
    rom[0x7FDA] = 0x00;
    rom[0x7FDB] = 0x00;
    // Vetores: reset/NMI/IRQ/BRK/COP -> $8000
    for (int off : {0x7FE4, 0x7FE6, 0x7FE8, 0x7FEA, 0x7FEE, 0x7FF4, 0x7FF6, 0x7FF8, 0x7FFA, 0x7FFC, 0x7FFE}) {
        rom[off] = 0x00; rom[off + 1] = 0x80;
    }
    // Checksum
    rom[0x7FDC] = rom[0x7FDD] = rom[0x7FDE] = rom[0x7FDF] = 0;
    uint32_t sum = 0;
    for (uint8_t b : rom) sum += b;
    const uint16_t cs = sum & 0xFFFF, inv = static_cast<uint16_t>(~cs);
    rom[0x7FDC] = inv & 0xFF; rom[0x7FDD] = inv >> 8;
    rom[0x7FDE] = cs & 0xFF;  rom[0x7FDF] = cs >> 8;
    return rom;
}

static void logger(int level, const char* msg) { std::printf("  [core %d] %s", level, msg); }

static int fails = 0;
#define CHECK(cond, ...) do { if (cond) std::printf("  ok:   " __VA_ARGS__); \
    else { std::printf("  FAIL: " __VA_ARGS__); ++fails; } std::printf("\n"); } while (0)

static uint32_t centerPixel(const fe::Video& v) {
    return v.rgba[(v.height / 2) * v.width + v.width / 2];
}

int main() {
    fe::setLogger(logger);
    std::system("mkdir -p /tmp/topgear_host_test");
    CHECK(fe::init("/tmp/topgear_host_test", "/tmp/topgear_host_test"), "init do core");

    auto rom = makeRom();
    CHECK(fe::loadGame(rom.data(), rom.size()), "loadGame");
    CHECK(fe::gameLoaded(), "jogo carregado");
    std::printf("  av: %.4f fps, %d Hz\n", fe::fps(), fe::sampleRate());
    CHECK(fe::sampleRate() == 32040, "sample rate 32040 Hz");
    CHECK(fe::fps() > 60.0 && fe::fps() < 60.2, "fps NTSC");

    // Sem botões: fundo vermelho.
    fe::setPad(0);
    size_t audioFrames = 0;
    std::vector<int16_t> abuf(4096 * 2);
    for (int i = 0; i < 20; ++i) {
        fe::runFrame();
        audioFrames += fe::readAudio(abuf.data(), 4096);
    }
    fe::Video v = fe::video();
    CHECK(v.rgba && v.width >= 256 && v.height >= 224, "video %dx%d", v.width, v.height);
    uint32_t p = centerPixel(v);
    const uint32_t r = p & 0xFF, g = (p >> 8) & 0xFF, b = (p >> 16) & 0xFF;
    CHECK(r > 200 && g < 30 && b < 30, "sem botoes: fundo vermelho (pixel=%08X)", p);
    CHECK(audioFrames > 20 * 500, "audio gerado (%zu quadros em 20 frames)", audioFrames);

    // Botão B: fundo verde (prova o caminho toque -> máscara -> $4219).
    fe::setPad(fe::BTN_B);
    for (int i = 0; i < 20; ++i) { fe::runFrame(); fe::readAudio(abuf.data(), 4096); }
    p = centerPixel(fe::video());
    const uint32_t r2 = p & 0xFF, g2 = (p >> 8) & 0xFF, b2 = (p >> 16) & 0xFF;
    CHECK(g2 > 200 && r2 < 30 && b2 < 30, "botao B: fundo verde (pixel=%08X)", p);

    // Soltou: volta ao vermelho.
    fe::setPad(0);
    for (int i = 0; i < 20; ++i) { fe::runFrame(); fe::readAudio(abuf.data(), 4096); }
    p = centerPixel(fe::video());
    CHECK((p & 0xFF) > 200 && ((p >> 8) & 0xFF) < 30, "soltou B: vermelho de novo (pixel=%08X)", p);

    fe::shutdown();
    std::printf(fails ? "\nRESULTADO: %d FALHA(S)\n" : "\nRESULTADO: TUDO OK\n", fails);
    return fails ? 1 : 0;
}
